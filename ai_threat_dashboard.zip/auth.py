from flask import request, redirect, session, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import jwt, datetime
import os
from database import users

SECRET_KEY = os.environ.get('SECRET_KEY', 'your_secret_key')

def register_user(email, password):
    if email in users:
        return "Email already exists"
    hashed = generate_password_hash(password)
    users[email] = hashed
    return redirect(url_for('login'))

def login_user(email, password):
    hashed = users.get(email)
    if hashed and check_password_hash(hashed, password):
        token = jwt.encode({'user': email, 'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)}, SECRET_KEY, algorithm="HS256")
        session['token'] = token
        session['user'] = email
        return redirect(url_for('index'))
    return "Invalid credentials"

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = session.get('token')
        if not token:
            return redirect(url_for('login'))
        try:
            jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        except:
            return "Token is invalid or expired"
        return f(*args, **kwargs)
    return decorated
