from flask import Flask, render_template, request, redirect, session, url_for
from auth import register_user, login_user, token_required
from threat_model import load_and_preprocess_data, train_model, predict_threat_level
import pandas as pd
import os

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your_secret_key')

file_path = "india_pakistan_2025_battlefield_dataset.csv"
X, y, le_dict, valid_categories, default_values_by_location, raw_df = load_and_preprocess_data(file_path)
rf_model, _, _, _ = train_model(X, y)
feature_names = X.columns.tolist()
current_df = raw_df.copy()

@app.route('/')
def index():
    if 'user' in session:
        return render_template('index.html')
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        return register_user(email, password)
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        return login_user(email, password)
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/predict', methods=['POST'])
@token_required
def predict():
    input_data = {
        'enemy_distance': float(request.form['enemy_distance']),
        'location': request.form['location'],
        'terrain_type': request.form['terrain_type'],
        'time_of_day': request.form['time_of_day']
    }
    threat_level, tactical_action = predict_threat_level(
        rf_model, input_data, le_dict,
        default_values_by_location, current_df, feature_names
    )
    return render_template('index.html', prediction=threat_level, action=tactical_action)

if __name__ == '__main__':
    app.run(debug=True)
