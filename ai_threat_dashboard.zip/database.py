# Simulated in-memory user database
users = {}
